
setInterval(setClock, 1000)

const hourHand=documnt.querySelector("[data-hour-hand]")
const minuteHand=documnt.querySelector("[data-minute-hand]")
const secondHand=documnt.querySelector("[data-second-hand]")

function setClock(){
    const currentDate=new Date()
    const secondsRatio=currentDate.getSeconds() / 60
    const minutesRatio=(secondsRatio + currentDate.getMinutes())
    const hoursRatio=(minutesRatio + currentDate.getHours()) /12

    setRotation(secondHand, secondsRatio)
    setRotation(minuteHand, minutesRatio)
    setRotation(hourHand, hoursRatio)

}

function setRatation(element, rotationRatio){
    element.style.setProperty("--rotationRatio",rotationRatio * 360 )
}
setClock()